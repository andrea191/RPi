//Install mqtt library using: npm install mqtt
var mqtt = require('mqtt');

var client = mqtt.connect({
  servers:[{'host':'mqtt.relayr.io'}],
  username: "c95f8570-2467-428c-a8bd-306ad73afd61",
  password: "eof35EppZMew",
  clientId: "TyV+FcCRnQoyovTBq1zr9YQ",
  protocol : 'mqtts'
});

function getRandomIntInclusive(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

client.on('connect', function() {

  //subscribe to commands sent from the dashboard or other clients
  client.subscribe("/v1/c95f8570-2467-428c-a8bd-306ad73afd61/cmd");

  client.on('message', function(topic, message) {
  });

  //simple timer to send a message every 1 second
  var publisher = setInterval(function(){

    // publish a message to a topic
    var tempRand = getRandomIntInclusive(-50, 50);
    var accRand = new Array();
	accRand[0]= getRandomIntInclusive(-250, 250);
	accRand[1]= getRandomIntInclusive(-250, 250);
	accRand[2]= getRandomIntInclusive(-250, 250);
    var data = JSON.stringify([
	{path:"cabin", meaning:"temperature", value: tempRand},
	{path:"helicopter", meaning:"acceleration", 
			value:accRand}
	]
	);

    client.publish("/v1/c95f8570-2467-428c-a8bd-306ad73afd61/data", data, function() {
    });

  }, 1000);

});
